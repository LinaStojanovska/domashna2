package com.example.project1.service;

import com.example.project1.model.DataArchiveEntity;
import com.example.project1.repository.DataArchiveRepository;
import com.example.project1.repository.EnterpriseRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.time.LocalDate;
import java.util.List;

@Service
@RequiredArgsConstructor
public class EnterpriseEntity {

    private final EnterpriseRepository enterpriseRepository;
    private final DataArchiveRepository dataArchiveRepository;

    public List<com.example.project1.model.EnterpriseEntity> findAll() {
        return enterpriseRepository.findAll();
    }

    public com.example.project1.model.EnterpriseEntity findById(Long id) throws Exception {
        return enterpriseRepository.findById(id).orElseThrow(Exception::new);
    }

    public List<DataArchiveEntity> findAllToday() {
        return dataArchiveRepository.findAllByDate(LocalDate.now());
    }

}
