package com.example.project1.repository;

import com.example.project1.model.EnterpriseEntity;
import com.example.project1.model.DataArchiveEntity;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.time.LocalDate;
import java.util.List;
import java.util.Optional;

@Repository
public interface DataArchiveRepository extends JpaRepository<DataArchiveEntity, Long> {
    Optional<DataArchiveEntity> findByDateAndCompany(LocalDate date, EnterpriseEntity company);
    List<DataArchiveEntity> findByCompanyIdAndDateBetween(Long companyId, LocalDate from, LocalDate to);
    List<DataArchiveEntity> findAllByDate(LocalDate date);
}
